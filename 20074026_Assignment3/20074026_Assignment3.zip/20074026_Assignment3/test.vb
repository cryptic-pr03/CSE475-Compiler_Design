Module PrimeCheck
    Sub Main() 'COMMENT
        Dim number As Integer
        Console.Write("Enter a number: ")
        number = Integer.Parse(Console.ReadLine())

        If IsPrime(number) Then
            Console.WriteLine(number & " is a prime number.")
        Else
            Console.WriteLine(number & " is not a prime number.")
        End If

    End Sub

    Function IsPrime(ByVal num As Integer) As Boolean
        Dim i As Integer = 1
        Dim factorCount As Integer = 0
        While i * i <= num
            If num Mod i = 0  Then
                factorCount += 1
            End If
            i += 1
        End While

        If factorCount > 2  Then
            Return True
        Else 
            Return False
        End If
    End Function
End Module
