Imports System

Module Program
    Sub Main()
        Console.Write("Enter a number: ")
        Dim number As Integer = Integer.Parse(Console.ReadLine())

        If number Mod 2 = 0 Then
            Console.WriteLine("{0} is even.", number)
        Else
            Console.WriteLine("{0} is odd.", number)
        End If
    End Sub
End Module